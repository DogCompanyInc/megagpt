# blackbox-api
 An unofficial api to work with blackbox.ai on python
 
 Example code:
 ```
 import blackbox
 prompt = input('Please input prompt: ')
 blackbox.blackbox('API_KEY', prompt)
 ```
